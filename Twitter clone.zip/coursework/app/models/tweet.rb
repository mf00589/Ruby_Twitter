class Tweet < ApplicationRecord
  belongs_to :user
  has_many :comments, dependent: :destroy
  validates :title, presence: true
  validates :title, uniqueness: true

  scope :user_tweets, ->(user) { where(['user_id = ?', user.id])}
end
