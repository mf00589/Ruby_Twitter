class Comment < ApplicationRecord
  belongs_to :tweet
  validates :title, :tweet, presence: true

  scope :user_comments, ->(user) { joins(:tweet).where(['user_id = ?', user.id])}
end
