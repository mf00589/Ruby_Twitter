class HomeController < ApplicationController

  def home
  end

  def contact
    def styletag(sheet_name)
    "<link rel='stylesheet' href='/assets/stylesheets/home.scss'>".html_safe
    end
  end
#method which is used get the user information for the contact mailer
#the information is validated and then the user is redirected to home page
  def request_contact
    name = params[:name]
    email = params[:email]
    telephone = params[:telephone]
    message = params[:message]

    if email.blank?
      flash[:alert] = I18n.t('home.request_contact.no_email')
    else
      # send an email
      ContactMailer.contact_email(email, name, telephone, message).deliver_now
      flash[:notice] = I18n.t('home.request_contact.email_sent')
    end

    redirect_to root_path
  end
end
