class ApplicationMailer < ActionMailer::Base
  default to: "info@mytweet.com", from: 'info@mytweet.com'
  layout 'mailer'
end
