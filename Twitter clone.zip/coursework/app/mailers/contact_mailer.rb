class ContactMailer < ApplicationMailer
#format of the conatc mailer
  def contact_email(email, name, telephone, message)
    @email = email
    @name = name
    @telephone = telephone
    @message = message

    mail cc: @email
  end

end
