require 'test_helper'

class TweetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  setup do
    @user = users(:one)
  end


  test 'should not save empty tweet' do
    tweet = Tweet.new

    tweet.save
    refute tweet.valid?
  end

  test 'should save valid tweet' do
    tweet = Tweet.new

    tweet.title = 'My Tweet'
    tweet.message = 'My First Tweet'
    tweet.user = @user

    tweet.save
    assert tweet.valid?
  end

  test 'should not save duplicate tweet title' do
    tweet1 = Tweet.new
    tweet1.title = 'My Tweet'
    tweet1.message = 'My First Tweet'
    tweet1.user = @user
    tweet1.save
    assert tweet1.valid?

    tweet2 = Tweet.new
    tweet2.title = 'My Tweet'
    tweet2.message = 'My First Tweet'
    tweet2.user = @user

    tweet2.save
    refute tweet2.valid?

  end

  test 'Should not save Tweet without message' do
    tweet = Tweet.new
    tweet.title = 'My Tweet'
    tweet.title = ''

    tweet.save
    refute tweet.valid?
  end

end
