require 'test_helper'

class CommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  setup do
    @tweet = tweets(:one)
  end

  test 'should not save empty Comment' do
    comment = Comment.new

    comment.save
    refute comment.valid?
  end

  test 'should save valid Comment' do
    comment = Comment.new

    comment.title = 'My Comment'
    comment.tweet = @tweet

    comment.save
    assert comment.valid?
  end
end
