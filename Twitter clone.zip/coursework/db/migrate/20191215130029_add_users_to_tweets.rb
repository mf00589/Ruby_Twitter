class AddUsersToTweets < ActiveRecord::Migration[5.2]
  def up
    add_reference :tweets, :user, index:true
    Tweet.reset_column_information
    user = User.first

    Tweet.all.each do |tweet|
      tweet.user_id = user.id
      tweet.save
    end

    change_column_null :tweets, :user_id, false
    add_foreign_key :tweets, :users
  end

  def down
    remove_foreign_key :tweets, :users
    remove_refernce :tweets, :user, index: true
  end
end
