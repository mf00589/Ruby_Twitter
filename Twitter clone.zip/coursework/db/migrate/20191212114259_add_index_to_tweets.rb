class AddIndexToTweets < ActiveRecord::Migration[5.2]
  def change
    add_index :tweets, :title, unique: true
  end
end
